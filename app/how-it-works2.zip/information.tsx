import { MyColors } from '@/constants/Colors'
import React from 'react'
import { Image, StyleSheet, Text, TextInput, View } from 'react-native'

const information = () => {
    return (
        <View style={styles.container}>
            <Image source={require('../assets/images/tecky-logo.png')} />

            <Text style={styles.topText}>Kindly input the following</Text>

            <View style={styles.inputContainer}>
                <Text style={styles.questionText}>NAME</Text>

                <TextInput
                    placeholder='Enter full name'
                    style={styles.input}
                    keyboardType='default'
                    // value=''
                    onChangeText={() => { }}
                />

                <Text style={styles.questionText}>EMAIL</Text>

                <TextInput
                    placeholder='Enter email address'
                    style={styles.input}
                    keyboardType='email-address'
                    // value=''
                    onChangeText={() => { }}
                />
            </View>
        </View>
    )
}

export default information

const styles = StyleSheet.create({
    container: {
        height: '100%',
        backgroundColor: 'white',
        padding: 20
    },
    topText: {
        fontSize: 16,
        fontWeight: 'regular',
        color: MyColors.textColor3,
        marginTop: 20
    },
    questionText: {
        fontSize: 14,
        fontWeight: 'regular',
        color: MyColors.textColor,
        marginTop: 4
    },
    inputContainer: {
        marginTop: 16
    },
    input: {
        borderWidth: 1,
        borderColor: MyColors.inputBorderColor,
        borderRadius: 6,
        padding: 16,
        marginTop: 8,
        color: MyColors.textColor3
    }
})